# Blog 2 social kit (Nov 26, 2026)

Rule: Drive doc "Riverstead Marketing and Social Rules", section 3 (every blog post and shared page gets a social picture and descriptions).

- `riverstead-blog2-share-1200x630.jpg`: link preview. Also in the site at `assets/art/social/blog-new-nerfs-and-best-of-3.jpg`.
- `riverstead-blog2-facebook-1080x1350.jpg`: Facebook / Instagram (4:5).
- `riverstead-blog2-discord-1920x1080.jpg`: Discord (16:9).
- Share link: https://playriverstead.com/blog/new-nerfs-and-best-of-3/
- Post text (Facebook, Discord, caption, alt text): Claude project doc `claude/Blog 2 - New Nerfs and Best of 3 (Nov 26, 2026).md`.

## Recipe
1. Serve the site: `python3 -m http.server 8765` in the repo.
2. In `recipe/`: `npm i playwright @fontsource/pirata-one @fontsource/alegreya-sc @fontsource/alegreya-sans @fontsource/jersey-10 @fontsource/eb-garamond @fontsource/pixelify-sans`
3. Edit the `POST` block in `social.js` (title, supporting line, three card names, banner) and run `node social.js <outdir>`. It writes PNGs at the three sizes; save as JPG (quality 88 to 90).
Cards are the live cards drawn by the site's own renderer. Background: `assets/art/banner/draven-1920.webp`.
