/* Shared helper: opens the local copy of the site with the real fonts and no network calls to Supabase. */
const {chromium}=require('playwright');const fs=require('fs');const path=require('path');
const FONTS={"Pirata One":["pirata-one",[400]],"Alegreya SC":["alegreya-sc",[500,700,800]],"Alegreya Sans":["alegreya-sans",[400,500,700],true],"Jersey 10":["jersey-10",[400]],"EB Garamond":["eb-garamond",[400,500,600,700]],"Pixelify Sans":["pixelify-sans",[400,700]]};
function fontCSS(){let css="";for(const[fam,[pkg,ws,ital]]of Object.entries(FONTS)){for(const w of ws){for(const st of(ital&&w===400?["normal","italic"]:["normal"])){const f=`node_modules/@fontsource/${pkg}/files/${pkg}-latin-${w}-${st}.woff2`;if(!fs.existsSync(path.join(__dirname,f)))continue;
  css+=`@font-face{font-family:"${fam}";font-style:${st};font-weight:${w};src:url(http://fonts.local/${f}) format("woff2")}\n`}}}return css}
async function open(url,opts={}){const b=await chromium.launch();const ctx=await b.newContext({viewport:opts.viewport||{width:1100,height:900},deviceScaleFactor:opts.dsf||2});
  if(opts.init)await ctx.addInitScript(opts.init);
  const p=await ctx.newPage();
  await p.route(/supabase\.co|jsdelivr|cdnjs/,r=>r.abort());
  await p.route(/fonts\.googleapis\.com/,r=>r.fulfill({contentType:"text/css",body:fontCSS(),headers:{"access-control-allow-origin":"*"}}));
  await p.route(/fonts\.local/,r=>{const f=path.join(__dirname,new URL(r.request().url()).pathname);r.fulfill({body:fs.readFileSync(f),contentType:"font/woff2",headers:{"access-control-allow-origin":"*"}})});
  p.on('pageerror',e=>console.log('PAGEERR',e.message.slice(0,200)));
  await p.goto(url,{waitUntil:'load'});await p.evaluate(()=>document.fonts.ready);await p.waitForTimeout(opts.wait||1500);
  return{b,p}}
module.exports={open};
