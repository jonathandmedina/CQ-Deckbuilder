/* Blog 2 social pictures. Run: node social.js <outdir>  (site served on localhost:8765)
   One layout drawn at three sizes: link preview 1200x630, Facebook/Instagram 4:5 (1080x1350), Discord 16:9 (1920x1080).
   Cards are the live cards drawn by the site's cardHTML (full card with frame, per the Style Guide section 9). */
const {open}=require('./lib');const OUT=process.argv[2]||'/home/claude/work/out';
const POST={kicker:"Riverstead Blog",title:"New Nerfs and Best of 3 Have Arrived!",sub:"Slower starts, earned snowballs, and Best of 3 matches with sideboards for everyone.",cards:["Venom Dancer","Mass Populate","Storm Caller"],banner:"assets/art/banner/draven-1920.webp",file:"riverstead-blog2"};
const SIZES=[["share-1200x630",1200,630],["facebook-1080x1350",1080,1350],["discord-1920x1080",1920,1080]];
(async()=>{for(const[name,W,H]of SIZES){
 const{b,p}=await open('http://localhost:8765/#blog',{dsf:1,viewport:{width:W,height:H},init:()=>{try{localStorage.setItem('cq.seen.blog1','1');localStorage.setItem('cq.tut.offered','1')}catch(e){}}});
 await p.evaluate(async({POST,W,H})=>{document.querySelectorAll('.modal').forEach(m=>m.remove());
  const tall=H>W;const u=Math.min(W,H)/630; /* scale unit */
  const all=[...BYID.values()];const cw=tall?W*0.30:Math.min(H*0.40,W*0.50/2.72);
  const st=document.createElement("div");st.id="soc";
  st.style.cssText=`position:fixed;left:0;top:0;width:${W}px;height:${H}px;z-index:99999;overflow:hidden;background:#120a07 url(${POST.banner}) center/cover no-repeat;font-family:'EB Garamond',serif;color:#fff5de`;
  const cards=POST.cards.map((n,i)=>{const c=all.find(x=>x.name===n);const rot=[-7,0,7][i],dy=[18,0,18][i];
    return`<div class="sc" style="width:${cw}px;margin:0 ${-cw*0.07}px;transform:translateY(${dy*u}px) rotate(${rot}deg);filter:drop-shadow(0 ${10*u}px ${14*u}px rgba(0,0,0,.75));z-index:${i===1?2:1}">${cardHTML(c,{})}</div>`}).join("");
  const text=`<div style="${tall?`text-align:center;padding:${44*u}px ${40*u}px 0`:`flex:0 0 46%;box-sizing:border-box;padding:0 ${10*u}px 0 ${48*u}px;min-width:0`}">
    <div style="font-size:${22*u}px;letter-spacing:.22em;text-transform:uppercase;color:#f1dcae;text-shadow:0 2px 0 #000">${POST.kicker}</div>
    <div style="font-family:'Pirata One',serif;font-size:${(tall?74:W/H>1.85?56:66)*u}px;line-height:1.02;margin:${10*u}px 0 ${14*u}px;color:#ffc35a;text-shadow:0 ${4*u}px 0 #000,0 0 ${24*u}px rgba(0,0,0,.8)">${POST.title}</div>
    <div style="font-size:${(tall?30:27)*u}px;line-height:1.25;text-shadow:0 2px 0 #000;max-width:${tall?"none":"92%"}">${POST.sub}</div>
    <div style="display:inline-block;margin-top:${20*u}px;padding:${7*u}px ${20*u}px;border-radius:999px;background:#e8b04a;color:#2a1608;font-weight:700;font-size:${24*u}px">playriverstead.com</div></div>`;
  const fan=`<div style="display:flex;justify-content:center;align-items:center;${tall?`padding:${30*u}px 0 ${50*u}px`:`flex:1;padding:0 ${40*u}px 0 0`}">${cards}</div>`;
  st.innerHTML=`<div style="position:absolute;inset:0;background:${tall?"linear-gradient(180deg,rgba(12,6,4,.9),rgba(12,6,4,.55) 45%,rgba(12,6,4,.75))":"linear-gradient(90deg,rgba(12,6,4,.93),rgba(12,6,4,.74) 46%,rgba(12,6,4,.2))"}"></div>
   <div style="position:absolute;inset:0;display:flex;${tall?"flex-direction:column;justify-content:space-between":"align-items:center"}">${text}${fan}</div>
   <div style="position:absolute;inset:${8*u}px;border:${3*u}px solid #b8743a;border-radius:${10*u}px;pointer-events:none"></div>`;
  document.body.appendChild(st);
  st.querySelectorAll(".sc>*").forEach(e=>{e.style.width="100%";e.style.margin="0"});st.querySelectorAll(".zoom").forEach(e=>e.remove());
  const im=[...st.querySelectorAll("img")];im.forEach(i=>{i.loading="eager"});
  await Promise.all(im.map(i=>i.complete&&i.naturalWidth?0:new Promise(r=>{i.onload=i.onerror=r;setTimeout(r,8000)})));
  await new Promise(r=>{const g=new Image();g.onload=g.onerror=r;g.src=POST.banner});await document.fonts.ready;await new Promise(r=>setTimeout(r,800))},{POST,W,H});
 await p.screenshot({path:`${OUT}/${POST.file}-${name}.png`,clip:{x:0,y:0,width:W,height:H}});await b.close();console.log(name)}
})();
